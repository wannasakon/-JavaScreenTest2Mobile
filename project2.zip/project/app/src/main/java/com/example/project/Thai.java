package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

public class Thai extends AppCompatActivity {
    ImageButton imageButton1,imageButton2,imageButton3,imageButton4,imageButton5,imageButton6,imageButton7,imageButton8;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thai);

        imageButton1 =(ImageButton) findViewById(R.id.imageButton1);
        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O1 =new Intent(Thai.this,Showthai.class);
                startActivity(O1);

            }
        });
        imageButton2 =(ImageButton) findViewById(R.id.imageButton2);
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O2 =new Intent(Thai.this,Showthai2.class);
                startActivity(O2);

            }
        });
        imageButton3 =(ImageButton) findViewById(R.id.imageButton3);
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O3 =new Intent(Thai.this,Showthai3.class);
                startActivity(O3);
            }
        });
        imageButton4 =(ImageButton) findViewById(R.id.imageButton4);
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O4 =new Intent(Thai.this,Showthai4.class);
                startActivity(O4);
            }
        });
        imageButton5 =(ImageButton) findViewById(R.id.imageButton5);
        imageButton5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O5 =new Intent(Thai.this,Showthai5.class);
                startActivity(O5);
            }
        });
        imageButton6 =(ImageButton) findViewById(R.id.imageButton6);
        imageButton6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O6 =new Intent(Thai.this,Showthai6.class);
                startActivity(O6);
            }
        });
        imageButton7 =(ImageButton) findViewById(R.id.imageButton7);
        imageButton7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O7 =new Intent(Thai.this,Showthai7.class);
                startActivity(O7);
            }
        });
        imageButton8 =(ImageButton) findViewById(R.id.imageButton8);
        imageButton8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O8 =new Intent(Thai.this,Showthai8.class);
                startActivity(O8);
            }
        });

    }


}

