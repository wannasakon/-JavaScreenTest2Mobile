package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class Jfood extends AppCompatActivity {
    ImageButton imageButton1,imageButton2,imageButton3,imageButton4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jfood);

        imageButton1 =(ImageButton) findViewById(R.id.imageButton1);
        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O1 =new Intent(Jfood.this,Jfood1.class);
                startActivity(O1);

            }
        });
        imageButton2 =(ImageButton) findViewById(R.id.imageButton2);
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O2 =new Intent(Jfood.this,Jfood2.class);
                startActivity(O2);

            }
        });
        imageButton3 =(ImageButton) findViewById(R.id.imageButton3);
        imageButton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O3 =new Intent(Jfood.this,Jfood3.class);
                startActivity(O3);
            }
        });
        imageButton4 =(ImageButton) findViewById(R.id.imageButton4);
        imageButton4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent O4 =new Intent(Jfood.this,Jfood4.class);
                startActivity(O4);
            }
        });
    }
}
