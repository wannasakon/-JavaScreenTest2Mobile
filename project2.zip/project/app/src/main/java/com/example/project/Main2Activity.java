package com.example.project;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class Main2Activity extends AppCompatActivity {
    TextView textView;
    Button bT,bJ,bS,bD,bH;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        textView =(TextView) findViewById(R.id.textView);
        bT =(Button)findViewById(R.id.bT);
        bT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bT = new Intent(Main2Activity.this,Thai.class);
                startActivity(bT);
            }
        });

        bJ =(Button)findViewById(R.id.bJ);
        bJ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bJ = new Intent(Main2Activity.this,Jfood.class);
                startActivity(bJ);
            }
        });

        bS =(Button)findViewById(R.id.bS);
        bS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bS = new Intent(Main2Activity.this,Sauce.class);
                startActivity(bS);
            }
        });

        bD =(Button)findViewById(R.id.bD);
        bD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bD = new Intent(Main2Activity.this,Dessert.class);
                startActivity(bD);
            }
        });

        bH =(Button)findViewById(R.id.bH);
        bH.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent bH = new Intent(Main2Activity.this,MainActivity.class);
                startActivity(bH);
            }
        });
    }
}
